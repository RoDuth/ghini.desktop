NsisMultiUser UMUI Full Demo, based on the Ultra Modern and ModernUIEx User Interfaces, using the standard MUI dialogs

Features:
- supports MULTIUSER_INSTALLMODE_ALLOW_BOTH_INSTALLATIONS values 0 AND 1
- fully uninstalls previously installed version (if any) by running its uninstaller before installing new version
- can safely downgrade and upgrade
- because previous version is fully uninstalled, user can set new installation folder, new start menu folder and choose different components

Limitations:
none